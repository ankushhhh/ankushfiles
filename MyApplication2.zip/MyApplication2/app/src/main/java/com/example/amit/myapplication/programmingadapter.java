package com.example.amit.myapplication;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Amit on 10-01-2019.
 */

public class programmingadapter extends RecyclerView.Adapter<programmingadapter.programmingviewholder> {
    private String[] data;
    public programmingadapter(String[] data)
    {
        this.data=data;
    }
    @Override
    public programmingviewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.list_item_layout, parent, false);
        return new programmingviewholder(view);
    }

    @Override
    public void onBindViewHolder(programmingviewholder holder, int position) {
        String title=data[position];
        holder.texttitle.setText(title);
    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class programmingviewholder extends RecyclerView.ViewHolder{
        ImageView imgicon;
        TextView texttitle;
        public programmingviewholder(View itemView) {
            super(itemView);
            imgicon= (ImageView) itemView.findViewById(R.id.imgicon);
            texttitle=(TextView) itemView.findViewById(R.id.texttitle);
        }
    }
}
