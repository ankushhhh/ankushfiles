package com.example.amit.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView programminglist = (RecyclerView) findViewById(R.id.programminglist);
        programminglist.setLayoutManager(new LinearLayoutManager(this));
        String[] names = {"name:ankush age:21", "name:amit age:30", "name:sachin age:12", "name:rahul age:21", "name:sathyn age:21", "name:sid age:40", "name:jack age:33"," name:chetana age:22","name:murare age:44","name:alex age:31" };
        programminglist.setAdapter(new programmingadapter(names));

    }
}
